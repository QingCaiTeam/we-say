package com.example.login_chatting

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
